/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.pkg1;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "Welcome to user regestration");
        String username = JOptionPane.showInputDialog(null, "Enter username");

        String password = JOptionPane.showInputDialog(null, "Enter password");

        String FirstName = JOptionPane.showInputDialog(null, "Enter first name");

        String LastName = JOptionPane.showInputDialog("Enter last name:");

        loginClass login = new loginClass(username, password, FirstName, LastName);
        String RegestrationStatus = login.RegisterUser();
        JOptionPane.showMessageDialog(null, RegestrationStatus);
        if (RegestrationStatus.equals(" User registration successful")) {

            boolean flag = false;
            while (!flag) {
                String inputUsername = JOptionPane.showInputDialog("Enter Username");

                String inputPassword = JOptionPane.showInputDialog("Enter Password");

                flag = login.loginUser(inputUsername, inputPassword);

                String loginMessage = login.returnLoginStatus(flag);
                JOptionPane.showMessageDialog(null, loginMessage);
            }
            
            while (true) {
                String option = JOptionPane.showInputDialog(null, "Please choose the following option: \n 1. Add tasks  \n 2. Show report  \n 3. Quit");
                int optionInt = Integer.parseInt(option);

                switch (optionInt) {
                    case 1:
                        int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "how many tasks would you like to enter"));
                        Task.inputTask(numberOfTasks);
//                        JOptionPane.showMessageDialog(null, Task.printTaskDetails());
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, " Coming soon");
                        break;
                    case 3:
                        break;

                }
                break;
            }
        }
    }

}
