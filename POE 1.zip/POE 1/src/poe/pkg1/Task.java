/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.pkg1;
//import java.util.Scanner; 

import javax.swing.JOptionPane;

public class Task {
//Declaration of all my arrays

    public static String Name[];
    public static int TaskNumber[];
    public static String TaskDescription[];
    public static String DeveloperDetails[];
    public static int TaskDuration[];
    public static String TaskID[];
    public static String TaskStatus[];

    //initalizing the number of tasks
    public static int NumberOfTasks = 0;
//incrimenting task number

    public static int TaskNumber() {

        return NumberOfTasks++;
    }
//this method adds the tasks that should be done

    public static void addTasks(String name, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskID, String taskStatus) {
        Name[taskNumber] = name;
        TaskNumber[taskNumber] = taskNumber;
        TaskDescription[taskNumber] = taskDescription;
        DeveloperDetails[taskNumber] = developerDetails;
        TaskDuration[taskNumber] = taskDuration;
        TaskID[taskNumber] = taskID;
        TaskStatus[taskNumber] = taskStatus;

    }

    //shows the details of the task inputted by the user
    public static void showTaskDetails(int index) {
        JOptionPane.showMessageDialog(null, printTaskDetails(index));
    }
//prints all of the details of the task inputted by the user at the end

    public static String printTaskDetails(int index) {
        String results = "";
        results += "\n Status: " + TaskStatus[index];
        results += "\n Developer details: " + DeveloperDetails[index];
        results += "\n Task number: " + TaskNumber[index];
        results += "\n Task name: " + Name[index];
        results += "\n Task description: " + TaskDescription[index];
        results += "\n Task ID: " + TaskID[index];
        results += "\n Task duration: " + TaskDuration[index];

        return results;
    }
//initalizes the arrays to the size of the number of tasks inputted by the user

    public static void setArraySize(int numberOfTasks) {
        Name = new String[numberOfTasks];
        TaskNumber = new int[numberOfTasks];
        TaskDescription = new String[numberOfTasks];
        DeveloperDetails = new String[numberOfTasks];
        TaskDuration = new int[numberOfTasks];
        TaskID = new String[numberOfTasks];
        TaskStatus = new String[numberOfTasks];

    }
//creates the task ID 

    public static String createTaskID(String Name, int taskNumber, String developerDetails) {
        String taskID = "";
        int startIndex = developerDetails.length() - 3;
        taskID = Name.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerDetails.substring(startIndex).toUpperCase();
        return taskID;
    }

//returns the total number of hours used for all the tasks added together
    public static int returnTotalHours(int taskDuration[]) {
        int a = 0;
        for (int i = 0; i < taskDuration.length; i++) {
            a += taskDuration[i];
        }
        return a;
    }
//caputuring the details of each individual task in the loop

    public static void inputTask(int numberOfTasks) {
        setArraySize(numberOfTasks);

        for (int x = 0; x < numberOfTasks; x++) {

            String taskStatus = "";
            taskStatus = JOptionPane.showInputDialog("Please select task status here "
                    + "\n Doing"
                    + "\n Done"
                    + "\n To Do");

            String DeveloperDetails = DeveloperDetails();

            int taskNumber = TaskNumber();

            String Name = Name();

            String taskDescription;

            do {
                taskDescription = taskDescription();
            } while (!checkTaskDescription(taskDescription));

            String TaskID = createTaskID(Name, taskNumber, DeveloperDetails);
            //String TaskStatus = ""; 

            int TaskDuration = TaskDuration();

            addTasks(Name, taskNumber, taskDescription, DeveloperDetails, TaskDuration, TaskID, taskStatus);
            showTaskDetails(taskNumber);
        }
    }
//declaring all the methods below 

    public static String Name() {
        String taskName = JOptionPane.showInputDialog("Please enter task name here");
        return taskName;

    }

    public static String DeveloperDetails() {
        String developerDetails = JOptionPane.showInputDialog("Please enter developer details here");
        return developerDetails;
    }

    public static String taskDescription() {
        String description = JOptionPane.showInputDialog("Enter task description here");
        return description;
    }

    public static int TaskDuration() {
        int duration = Integer.parseInt(JOptionPane.showInputDialog("enter your estimated task duration here"));
        return duration;
    }

    public static boolean checkTaskDescription(String TaskLength) {
        if (TaskLength.length() <= 50) {
            JOptionPane.showMessageDialog(null, "Task successfully captured");
            return true;
        } else {
            if (TaskLength.length() > 50) {
                JOptionPane.showMessageDialog(null, "Pleas eenter a task description of less than 50 characters");
            }
            return false;
        }
    }
}

   
