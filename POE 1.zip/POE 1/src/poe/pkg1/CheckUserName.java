/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe.pkg1;

import java.util.Scanner;




public class CheckUserName {
    
    public static void main(String[] args) {

Scanner input = new Scanner(System.in);

Main.main(args);
/*
        System.out.println("Please enter your username here: ");
        String username = input.next();
     checkUsername(username);
        */
    }
   // Nyiko Masinge 
    //this method tests the username to see if it meets the requirements 
    
    public static boolean checkUsername(String MyName) {
        if (MyName.length() <= 5 && MyName.contains("_")) {
            System.out.println(" Username successfully captured");
            return true;
        } else {
            System.out.println(" Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length ");
            return false;
        }

    }
}

