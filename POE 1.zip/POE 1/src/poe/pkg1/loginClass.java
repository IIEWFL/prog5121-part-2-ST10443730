/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.pkg1;

/**
 *
 * @author konim
 */
public class loginClass {

    private String Username;
    private String Password;
    private String FirstName;
    private String LastName;

    public loginClass(String Username, String Password, String FirstName, String LastName) {
        this.Username = Username;
        this.Password = Password;
        this.FirstName = FirstName;
        this.LastName = LastName;
    }

    public String toString() {
        return Username;
    }

    public boolean checkPasswordComplexity() {
        boolean hasSpecial = false;
        boolean hasUpperCase = false;
        boolean hasNumber = false;

        for (char ch : Password.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                hasUpperCase = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (" !@#$%^&*?|/~".indexOf(ch) != -1) {
                hasSpecial = true;
            }
        }

        return Password.length() >= 8 && hasSpecial && hasUpperCase && hasNumber;

    }

    public boolean checkUsername() {
        if (Username.length() <= 5 && Username.contains("_")) {
            System.out.println(" Username successfully captured");
            return true;
        } else {
            System.out.println(" Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length ");
            return false;
        }
    }

    public String RegisterUser() {
        if (!checkUsername()) {
            return "Username is incorrect, please try again";
        } else if (!checkPasswordComplexity()) {
            return "Password is incorrect, please try again";
        } else {
            return " User registration successful";
        }
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome to EasyKanban";
        } else {

            return "Password or Username is incorrect. please try again";
        }
    }

    public boolean loginUser(String inputUsername, String inputPassword) {
        return inputUsername.equals(Username) && inputPassword.equals(Password);
    }
}
