/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.pkg1;

import java.util.Scanner;

public class CheckPassword {
 // this method tells the compiler what the requirements of the password are 
    public static boolean checkPasswordComplexity(String password) {
        boolean hasSpecial = false;
        boolean hasUpperCase = false;
        boolean hasNumber = false;

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                hasUpperCase = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (" !@#$%^&*?|/~".indexOf(ch) != -1) {
                hasSpecial = true;
            }
        }

        return password.length() >= 8 && hasSpecial && hasUpperCase && hasNumber;

    }
//this method determines whether the password inserted meets the requirements or not
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your passwowd here");
        String password = scanner.nextLine();

        if (checkPasswordComplexity(password)) {
            System.out.println("Password has been captured successfully");
        } else {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character");
        }
    }

}
