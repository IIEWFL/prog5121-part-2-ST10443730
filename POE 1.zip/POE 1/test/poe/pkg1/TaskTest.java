/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poe.pkg1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author konim
 */
public class TaskTest {

    public TaskTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of TaskNumber method, of class Task.
     */
    @Test
    public void testTaskNumber() {
        System.out.println("TaskNumber");
        int expResult = 0;
        int result = Task.TaskNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTasks method, of class Task.
     */
    @Test
    public void testAddTasks() {
        System.out.println("addTasks");
        String name = "";
        int taskNumber = 0;
        String taskDescription = "";
        String developerDetails = "";
        int taskDuration = 0;
        String taskID = "";
        String taskStatus = "";
        Task.addTasks(name, taskNumber, taskDescription, developerDetails, taskDuration, taskID, taskStatus);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showTaskDetails method, of class Task.
     */
    @Test
    public void testShowTaskDetails() {
        System.out.println("showTaskDetails");
        int index = 0;
        Task.showTaskDetails(index);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTaskDetails method, of class Task.
     */
    @Test
    public void testPrintTaskDetails() {
        System.out.println("printTaskDetails");

        int index = 0;
        String expResult = "\n Status: To Do"
                + "\n Developer details: Robyn Harrison"
                + "\n Task number: 0"
                + "\n Task name: Login Feature"
                + "\n Task description: Create login to authenticate users"
                + "\n Task ID: LO:0:SON"
                + "\n Task duration: 8";
               

        Task.setArraySize(1);
        
        String c = "Login Feature";
        String d = "Robyn Harrison";
        String e = "Create login to authenticate users";
        int s = Task.TaskNumber();
        int t = 8;
        String f = "To Do";
       String g = Task.createTaskID(c, s, d);
        Task.addTasks(c, s, e, d, t, g, f);
        String result = Task.printTaskDetails(index);
 assertEquals(expResult, result);
    }

    /**
     * Test of setArraySize method, of class Task.
     */
    @Test
    public void testSetArraySize() {
        System.out.println("setArraySize");
        int numberOfTasks = 0;
        Task.setArraySize(numberOfTasks);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createTaskID method, of class Task.
     */
    @Test
    public void testCreateTaskID() {
        System.out.println("createTaskID");
        String Name = "live life";
        int taskNumber = 0;
        String developerDetails = "Uthandile Nkosi";
        String expResult = "LI:0:OSI";
        String result = Task.createTaskID(Name, taskNumber, developerDetails);
        assertEquals(expResult, result);

    }

    /**
     * Test of returnTotalHours method, of class Task.
     */
    @Test
    public void testReturnTotalHours() {
        System.out.println("returnTotalHours");
        int expResult = 15;
        int[] duration = {5, 10};
        int result = Task.returnTotalHours(duration);
        assertEquals(expResult, result);

    }

    /**
     * Test of inputTask method, of class Task.
     */
    @Test
    public void testInputTask() {
        System.out.println("inputTask");
        int numberOfTasks = 0;
        Task.inputTask(numberOfTasks);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Name method, of class Task.
     */
    @Test
    public void testName() {
        System.out.println("Name");
        String expResult = "";
        String result = Task.Name();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DeveloperDetails method, of class Task.
     */
    @Test
    public void testDeveloperDetails() {
        System.out.println("DeveloperDetails");
        String expResult = "";
        String result = Task.DeveloperDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskDescription method, of class Task.
     */
    @Test
    public void testTaskDescription() {
        System.out.println("taskDescription");
        String expResult = "";
        String result = Task.taskDescription();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TaskDuration method, of class Task.
     */
    @Test
    public void testTaskDuration() {
        System.out.println("TaskDuration");
        int expResult = 0;
        int result = Task.TaskDuration();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkTaskDescription method, of class Task.
     */
    @Test
    public void testCheckTaskDescription() {
        System.out.println("checkTaskDescription");
        String TaskLength = "hieiehboporkbgpiu";
        boolean expResult = true;
        boolean result = Task.checkTaskDescription(TaskLength);
        assertEquals(expResult, result);

        String TaskLength2 = "hieiehboporkbgpiuhthfufuftdjuhyfjujhiyfugiyfgdhedfhfjvfj";
        boolean expResult2 = false;
        boolean result2 = Task.checkTaskDescription(TaskLength2);
        assertEquals(expResult2, result2);

    }

}
