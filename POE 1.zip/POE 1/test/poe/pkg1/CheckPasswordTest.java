/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poe.pkg1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author konim
 */
public class CheckPasswordTest {
    
    public CheckPasswordTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
     @Test
    public void checkPasswordComplexity() 
    { String testString = "wertyuiop";
        assertFalse(CheckPassword.checkPasswordComplexity("wertyuiop"));
        
        assertTrue(CheckPassword.checkPasswordComplexity("Koni003@"));
        
         assertFalse(CheckPassword.checkPasswordComplexity("Koni0039"));
         assertFalse(CheckPassword.checkPasswordComplexity("koni003#"));
        
    }
    
}
